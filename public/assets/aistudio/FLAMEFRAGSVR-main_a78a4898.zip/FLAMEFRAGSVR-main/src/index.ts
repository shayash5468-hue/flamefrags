import * as xb from 'xrblocks';
import { InvestigationHUD } from './ui/InvestigationHUD.ts';
import { gatherDeviceInfo } from './utils/deviceDetection.ts';
import {
  ExplorerStateSnapshot,
  FlameFragsExplorerScript,
} from './xr/FlameFragsExplorerScript.ts';

async function bootstrap(): Promise<void> {
  const root = document.getElementById('root');
  if (!root) {
    throw new Error('Root mount element #root not found.');
  }

  const deviceInfo = await gatherDeviceInfo();

  let hud: InvestigationHUD | null = null;

  const explorer = new FlameFragsExplorerScript(
    (snapshot: ExplorerStateSnapshot) => {
      hud?.updateSnapshot(snapshot);
    },
    (message: string) => {
      hud?.showError(message);
    }
  );

  hud = new InvestigationHUD(root, explorer, deviceInfo);

  const options = new xb.Options();
  options.enableVR();
  options.enableControllers();
  options.enableHands();
  options.enableReticles();
  options.referenceSpaceType = 'local-floor';
  options.framebufferScaleFactor = 1.0;
  options.controllers.visualizeRays = true;
  options.xrButton.enabled = false;
  options.enableSimulator = false;
  options.camera.near = 0.04;
  options.camera.far = 250;
  options.setAppTitle('FlameFrags – Historical VR Explorer');
  options.setAppDescription(
    'Interactive 3D & WebXR scientific investigation of Apollo 1 (1967), Apollo 13 (1970), and Mir (1997).'
  );

  try {
    xb.add(explorer);
    await xb.init(options);
    hud.markReady(explorer.getSnapshot());
  } catch (err) {
    const msg =
      err instanceof Error
        ? err.message
        : 'Unable to start 3D WebGL / WebXR renderer.';
    hud.showError(msg);
  }
}

document.addEventListener('DOMContentLoaded', () => {
  void bootstrap();
});
